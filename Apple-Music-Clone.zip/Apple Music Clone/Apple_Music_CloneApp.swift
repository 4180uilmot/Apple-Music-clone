//
//  Apple_Music_CloneApp.swift
//  Apple Music Clone
//
//  Created by Tom Liu on 2022/10/2.
//

import SwiftUI

@main
struct Apple_Music_CloneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
