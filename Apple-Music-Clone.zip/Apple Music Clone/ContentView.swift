//
//  ContentView.swift
//  Apple Music Clone
//
//  Created by Tom Liu on 2022/10/2.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            VStack {
                HStack {
                    Spacer()
                    Image(systemName: "ellipsis").resizable().scaledToFit().frame(width: 22, height: 22, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/).foregroundColor(Color.init(red: 231/255, green: 62/255, blue: 68/255)).rotationEffect(Angle.init(degrees: 90)).padding(.bottom, 8.0)
                }.padding([.top, .leading, .bottom], 8)
                VStack {
                    HStack {
                        Text("資料庫")
                            .font(.largeTitle)
                            .fontWeight(.medium)
                        Spacer()
                        Text("編輯").foregroundColor(Color.init(red: 231/255, green: 62/255, blue: 68/255)).padding(.top, 16)
                        
                    }
                    ListDividerView()
                        .padding(.top, -8.0)
                    ListView(listIcon: "music.note.list", listName: "播放列表")
                    ListDividerView()
                    ListView(listIcon: "music.mic", listName: "藝人")
                    ListDividerView()
                    ListView(listIcon: "square.stack", listName: "專輯")
                    ListDividerView()
                    ListView(listIcon: "music.note", listName: "歌曲")
                    ListDividerView()
                }
                VStack {
                    HStack {
                        Text("最近加入")
                            .font(.title2)
                            .fontWeight(.medium)
                        Spacer()
                    }
                    HStack {
                        AlbumView(albumCover: "SOUR_AlbumCover", albumName: "SOUR", author: "Oliva Rodrigo")
                        Spacer()
                        AlbumView(albumCover: "R_AlbumCover", albumName: "R - Single", author: "ROSÉ")
                    }
                }
                
                Spacer()
            }.padding(.all, 16)
            
            VStack {
                Spacer()
                ListDividerView()
                    .padding(.bottom, -16.0).shadow(color: .black/*@END_MENU_TOKEN@*/, radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/, x: /*@START_MENU_TOKEN@*/0.0, y: -10).offset(x: 0, y: 16)
                HStack(alignment: .center) {
                    Spacer().frame(width: 8.0)
                    Image("Diamonds_AlbumCover").resizable().frame(width: 52, height: 52, alignment: .center).cornerRadius(5.0)
                    Spacer()
                    Text("Rocket Man (I Think It's going to Be a Long Long Time)").frame(height: 20.0)
                    Spacer()
                    Image(systemName: "play.fill").resizable().scaledToFit().frame(width: 20.0, height: 20.0)
                    Spacer()
                        .frame(width: /*@START_MENU_TOKEN@*/16.0/*@END_MENU_TOKEN@*/)
                        
                    Image(systemName: "forward.fill").resizable().scaledToFit().frame(width: 30.0, height: 30.0)
                    Spacer()
                }.padding(.all, 8).background(Color.white).offset(x: 0, y: 16)
                Divider().frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: 1, alignment: .center).overlay(Color.init(red: 198/255, green: 198/255, blue: 199/255)).padding(.top, -8.0).offset(x: 0, y: 15)
                HStack(alignment: .center) {
                    BtnNavTab(tabIcon: "play.circle.fill", tabName: "立即聆聽", tabColor: Color.init(red: 138/255, green: 137/255, blue: 141/255))
                    BtnNavTab(tabIcon: "square.grid.2x2.fill", tabName: "瀏覽", tabColor: Color.init(red: 138/255, green: 137/255, blue: 141/255))
                    BtnNavTab(tabIcon: "dot.radiowaves.left.and.right", tabName: "廣播", tabColor: Color.init(red: 138/255, green: 137/255, blue: 141/255))
                    BtnNavTab(tabIcon: "square.stack.fill", tabName: "資料庫", tabColor: Color.init(red: 231/255, green: 62/255, blue: 68/255))
                    BtnNavTab(tabIcon: "magnifyingglass", tabName: "搜尋", tabColor: Color.init(red: 138/255, green: 137/255, blue: 141/255))
                }.padding(.horizontal, 16.0).background(Color.white).offset(x: 0.0, y: 8.0)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct BtnNavTab: View {
    let tabIcon: String
    let tabName: String
    let tabColor: Color
    
    var body: some View {
        VStack(alignment: .center) {
            Image(systemName: tabIcon).resizable().scaledToFit().foregroundColor(tabColor).frame(width: 22, height: 22, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            Spacer().frame(height: 8.0)
            Text(tabName).font(.footnote).fontWeight(.black).foregroundColor(tabColor).frame(width: 72.0, height: /*@START_MENU_TOKEN@*/18.0/*@END_MENU_TOKEN@*/)
        }.frame(minWidth: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/, maxWidth: 70, minHeight: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/, maxHeight: 54, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
    }
}

struct ListView: View {
    let listIcon: String
    let listName: String
    
    var body: some View {
        HStack {
            Image(systemName: listIcon).resizable().scaledToFit().frame(width: 24, height: 24, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/).foregroundColor(Color.init(red: 231/255, green: 62/255, blue: 68/255))
            Text(listName)
                .font(.title3)
            Spacer()
        }.padding(.vertical, 2.0)
    }
}

struct ListDividerView: View {
    var body: some View {
        Divider().frame(minWidth: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/, maxWidth: .infinity, minHeight: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/, maxHeight: 1, alignment: .center).overlay(Color.init(red: 198/255, green: 198/255, blue: 199/255)).padding(.vertical, 8.0)
    }
}

struct AlbumView: View {
    let albumCover: String
    let albumName: String
    let author: String
    
    
    var body: some View {
        VStack(alignment: .leading) {
            Image(albumCover).resizable().scaledToFit().frame(width: 170, height: 170, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/).cornerRadius(/*@START_MENU_TOKEN@*/5.0/*@END_MENU_TOKEN@*/)
            Text(albumName)
            Text(author)
                .foregroundColor(Color.init(red: 138/255, green: 137/255, blue: 141/255))
        }
    }
}
